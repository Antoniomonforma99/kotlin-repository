package com.salesianostriana.dam.ejerciciojpakotlin

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class EjercicioJpaKotlinApplicationTests {

	@Test
	fun contextLoads() {
	}

}
